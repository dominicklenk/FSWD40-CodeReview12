<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package cr12_dominic_klenk_traveler
 */

get_header();
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

		<?php if ( have_posts() ) : ?>

			<div class="container-fluid">
				<header>
						<div class="jumbotron text-center">
								<h1>Welcome to <?php bloginfo('name') ?></h1>
						</div>
					<?php dynamic_sidebar('travelmenu') ?>
				</header>
			</div>
			<div class="container">
				<div class="row pt-3 pb-3">

			<?php
			/* Start the Loop */
			while ( have_posts() ) :
				the_post();

				/*
				 * Include the Post-Type-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Type name) and that will be used instead.
				 */
				?>
				<div class="col-lg-4 col-md-4 col-sm-12 mx-auto">
          			<div class="card mb-3">
			<?php	get_template_part( 'template-parts/content', get_post_type() );?>

			</div>
				</div>

			<?php endwhile;

			the_posts_navigation();

		else :

			get_template_part( 'template-parts/content', 'none' );

		endif;
		?>
		</div>
		</div>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php
//get_sidebar();
get_footer();
echo '<!-- archive.php -->';