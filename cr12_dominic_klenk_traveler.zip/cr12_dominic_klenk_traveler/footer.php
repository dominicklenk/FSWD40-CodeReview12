<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_dominic_klenk_traveler
 */

?>

	</div><!-- #content -->

	<footer id="colophon" class="blog-footer bg-secondary text-white">
		<hr>
		<div class="site-info container text-center">
			
				<?php
				/* translators: 1: Theme name, 2: Theme author. */
				printf( esc_html__( 'Theme: %1$s by %2$s.', 'cr12_dominic_klenk_traveler' ), 'cr12_dominic_klenk_traveler', '<a href="https://www.codefactory.academy/dominic-klenk">Dominic Klenk</a>' );
				?>
				<p style="margin-bottom: 0;padding-bottom: 20px;"> &copy; <?php echo Date('Y'); ?> - <?php bloginfo('name'); ?> </p>
		</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

<?php //wp_footer(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/bootstrap.js"></script>
</body>
</html>
<?php echo '<!-- footer.php -->';?>